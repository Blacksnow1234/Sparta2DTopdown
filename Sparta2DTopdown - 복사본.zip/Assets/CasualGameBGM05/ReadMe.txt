Casual Game BGM Pack #5 

It is a game sound with a theme of cute casual game.
All music files are made in WAV 441 16bit.
music is a loop.
It is free. It is freely usable.
Do not resell.

--------Contents-----

BGM_01 - WAV/ 441Hz/ 16Bit/ Loop/ 01:09 - A bright and exciting theme park feel.

BGM_02 - WAV/ 441Hz/ 16Bit/ Loop/ 00:14 - A simple song that fits the loading screen.

BGM_03 - WAV/ 441Hz/ 16Bit/ Loop/ 01:15 - A cute song suitable for casual game titles.

BGM_04 - WAV/ 441Hz/ 16Bit/ Loop/ 00:27 - A cute song suitable for casual game titles.

If you have any problems with the product, please contact us by e-mail.

4crain@gmail.com