﻿using System; // C# 기본 라이브러리
using UnityEngine; // 유니티 엔진의 기본 기능을 사용하기 위한 네임스페이스

public class TopDownShooting : MonoBehaviour
{
    private TopDownController controller; // TopDownController 컴포넌트를 참조하기 위한 변수

    [SerializeField] private Transform projectileSpawnPosition; // 발사체 생성 위치를 지정하기 위한 변수
    private Vector2 aimDirection = Vector2.right; // 발사체의 발사 방향을 저장하기 위한 변수, 초기값은 오른쪽

    public GameObject testPrefab; // 테스트용 발사체 프리팹

    private void Awake()
    {
        controller = GetComponent<TopDownController>(); // TopDownController 컴포넌트를 가져옴
    }

    private void Start()
    {
        controller.OnAttackEvent += OnShoot; // 공격 이벤트에 OnShoot 메서드를 등록
        controller.OnLookEvent += OnAim; // 시점 이동 이벤트에 OnAim 메서드를 등록
    }

    // 시점 이동 이벤트 핸들러
    private void OnAim(Vector2 direction)
    {
        aimDirection = direction; // 시점 이동 이벤트로부터 받은 방향을 aimDirection 변수에 저장
    }

    // 공격 이벤트 핸들러
    private void OnShoot()
    {
        CreateProjectile(); // 발사체 생성 함수 호출
    }

    // 발사체 생성 함수
    private void CreateProjectile()
    {
        // 발사체 프리팹을 발사체 생성 위치에 생성하고, 회전 없이 생성
        Instantiate(testPrefab, projectileSpawnPosition.position, Quaternion.identity);
    }
}
